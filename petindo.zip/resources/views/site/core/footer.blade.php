        <!-- footer -->
        <footer class="footer-v1">
            <!-- header-footer -->
            <div class="header-footer">
              <div class="container-fluid">
                <div class="row">
                  <div class="col-md-8 col-sm-12 footer-info-left  ">
                    <div class="row">
                      <div class="col-md-3 col-sm-3">
                        <h3>Get Help</h3>
                        <ul>
                          <li><a href="#">Order Status</a></li>
                          <li><a href="#">Shipping and Delivery</a></li>
                          <li><a href="#">Returns</a></li>
                          <li><a href="#">Pay ment Options</a></li>
                          <li><a href="#">Contact Us</a></li>
                        </ul>
                      </div>
                      <div class="col-md-3 col-sm-3">
                        <h3>My Account</h3>
                        <ul>
                          <li><a href="#">About us</a></li>
                          <li><a href="#">Delivery infomation</a></li>
                          <li><a href="#">Privy Policy </a></li>
                          <li><a href="#">Discount</a></li>
                          <li><a href="#">Custom Service</a></li>
                        </ul>
                      </div>
                      <div class="col-md-3 col-sm-3">
                        <h3>Link</h3>
                        <ul>
                          <li><a href="#">Home</a></li>
                          <li><a href="#">About us</a></li>
                          <li><a href="#">Back in Stock</a></li>
                          <li><a href="#">Blog </a></li>
                          <li><a href="#">Advanced Search</a></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-12 contact-footer-left ">
                    <h2>Indo<span>Pet</span></h2>
                    <h5>Open: 9:00 AM - Close: 05:00 PM</h5>
                    <p>
                      Hadir dengan menawarkan makanan kucing dan anjing termurah di Jakarta. Nikmati diskon sampai dengan 20% untuk kebutuhan pet anda.
                    </p>
                    <ul class="contact-adress">
                      <li>
                        <span><img src="images/icon-maps.png" alt=""/></span
                        >BISMART. Jalan 1 Maret No 90E. Cengkareng.
                      </li>
                      <!-- <li>
                        <span><img src="images/icon-phone.png" alt=""/></span
                        >1-800-806-6453
                      </li> -->
                      <li>
                        <span><img src="images/icon-evelop.png" alt=""/></span
                        >cs@indopet.id
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <!-- end header-footer -->
            <!-- bottom-footer -->
            <div class="bottom-footer">
              <div class="footer-copyright ">
                <div class="container-fluid">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="col-md-6 col-sm-7 col-60">
                        <address class="copyright">
                          Copyright © 2020 by <a href="#">IndoPet </a>. All
                          Rights Reserved.
                        </address>
                      </div>
                      <div class="col-md-6 col-sm-5 col-40">
                        <div class="payment">
                          <a href="#" class="visa"
                            ><i class="fa fa-facebook"></i
                          ></a>
                          <a href="#" class="american-express"
                            ><i class="fa fa-instagram"></i
                          ></a>
                          <a href="#" class="discover"
                            ><i class="fa fa-twitter"></i
                          ></a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- end bottom-footer -->
          </footer>
          <!-- end-footer -->