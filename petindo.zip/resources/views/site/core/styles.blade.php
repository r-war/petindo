  <!-- favicon -->
<link rel="icon" type="images/favicon" href="{{ asset('frontend/images/favicon.png') }}" />
<!-- menu-mobile CSS -->
<link rel="stylesheet" type="text/css" href="{{ asset('frontend/css/menu-mobile.css') }}" />
<!-- revolution CSS -->
<link rel="stylesheet" type="text/css" href="{{ asset('frontend/css/revolution.css') }}" />
<link rel="stylesheet" type="text/css" href="{{ asset('frontend/css/revolution2.css') }}" />
<!-- swiper CSS -->
<link rel="stylesheet" type="text/css" href="{{ asset('frontend/css/swiper.min.css') }}" />
<link rel="stylesheet" type="text/css" href="{{ asset('frontend/css/animate.min.css') }}" />
<!-- Style CSS -->
<link rel="stylesheet" type="text/css" href="{{ asset('frontend/css/style.css') }}" />

<link rel="stylesheet" type="text/css" href="{{ asset('frontend/css/custom.css') }}" />