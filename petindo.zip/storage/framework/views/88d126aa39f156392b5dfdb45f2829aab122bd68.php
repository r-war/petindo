  <!-- favicon -->
<link rel="icon" type="images/favicon" href="<?php echo e(asset('frontend/images/favicon.png')); ?>" />
<!-- menu-mobile CSS -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/css/menu-mobile.css')); ?>" />
<!-- revolution CSS -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/css/revolution.css')); ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/css/revolution2.css')); ?>" />
<!-- swiper CSS -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/css/swiper.min.css')); ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/css/animate.min.css')); ?>" />
<!-- Style CSS -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/css/style.css')); ?>" />

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/css/custom.css')); ?>" /><?php /**PATH C:\laragon\www\petindo\resources\views/site/core/styles.blade.php ENDPATH**/ ?>