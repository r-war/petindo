<div class="main-home-left-sidebar main-grid-left-sidebar">
    <!-- categories-left -->
    <div class="widget-v2 categories-left">
      <aside class="categories-grid-inner">
        <div class="sb-title ">
          <h4>Kategori</h4>
        </div>
        <div class="categories-nav">
          <div class="toggle-dropdown-menu">
            <ul>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($item->id !=1): ?>
                <li class="lever0">
                  <a href="<?php echo e(route('category.show',$item->slug)); ?>"><span><?php echo e($item->name); ?></span></a>
                </li>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        </div>
      </aside>
    </div>
    <!--end categories-left -->
    <!--start shop by -->
    <aside class="widget-v2 shopby">
      <div class="sb-title ">
        <h4>Shop by</h4>
      </div>
      <div class="shopby-inner">
        <div class="shopby-widget">
          <h3>Brand</h3>
          <ul>
            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
              <a href="<?php echo e(route('brand.show',$brand->slug)); ?>"><?php echo e($brand->name); ?><span class="count">(<?php echo e($brand->products->count()); ?>)</span></a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
        
      </div>
    </aside>
    <!--end -->
</div><?php /**PATH C:\laragon\www\petindo\resources\views/site/core/sidebar.blade.php ENDPATH**/ ?>