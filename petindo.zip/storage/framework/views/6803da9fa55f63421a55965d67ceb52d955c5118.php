<?php $__env->startSection('title', $category->name); ?>
<?php $__env->startSection('content'); ?>
    <section class="main-home main-home-v2 main-blog">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-10 col-md-9- col-sm-8 col-xs-12 col-75 col-col-right">
                    <div
                        class="main-home-page-right-content main-home-page-right-content-grid"
                    >
                        <div class="right-content-detail">
                            <!-- banner -->
                            <div class="banner-grid scale">
                                <img
                                    src="https://ecs7.tokopedia.net/img/cache/1190/shops-1/2019/2/8/48363349/48363349_f470f4bd-67d9-4a2b-bffb-a89a044b487e.jpeg"
                                    alt=""
                                />
                            </div>
                            <!-- bestsellerproduct -->
                            <div
                                class="product-view-grid product-view-grid-02"
                                id="tabs-grid" style="margin-top:50px"
                            >
                                <div class="products-grid row fivecolumns">
                                  <?php $__empty_1 = true; $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 products-mb">
                                        <!-- item-inner -->
                                        <div class="item-inner">
                                            <?php if($product->images->count() > 0): ?>
                                                <div class="box-images">
                                                <a class="product-image" href="<?php echo e(route('product.show', $product->slug)); ?>" title=""
                                                    ><img
                                                    src="<?php echo e(asset('storage/'.$product->images->first()->full)); ?>"
                                                    alt=""
                                                /></a>
                                                </div>
                                            <?php else: ?>
                                                <div class="box-images">
                                                <a class="product-image" href="<?php echo e(route('product.show', $product->slug)); ?>" title=""
                                                    ><img
                                                    src="https://via.placeholder.com/176"
                                                    alt=""
                                                /></a>
                                                </div>
                                            <?php endif; ?>
                                            <div class="product-shop">
                                            <h2 class="product-name">
                                                <a href="<?php echo e(route('product.show', $product->slug)); ?>" title=""
                                                ><?php echo e($product->name); ?></a
                                                >
                                            </h2>
                                            <?php if($product->sub_name != ''): ?>
                                                
                                                <div class="sub-name"><?php echo e($product->sub_name); ?></div>
                                            <?php endif; ?>
                                            <div class="price-box">
                                                <p class="special-price">
                                                    <span class="price-label">Special Price</span>
                                                    <span class="price"><?php echo e(config('settings.currency_symbol').$product->price); ?></span>
                                                </p>
                                                <?php if($product->sale_price !=0): ?>
                                                    <p class="old-price">
                                                    <span class="price-label">Special Price</span>
                                                    <span class="price"><?php echo e(config('settings.currency_symbol').$product->sale_price); ?></span>
                                                    </p>
                                                <?php endif; ?>
                                            </div>
                                            <ul class="add-to-links">
                                                <li class="cart">
                                                <a href="<?php echo e(route('product.add.cart.sku',$product->sku)); ?>" class="view-link" title=""
                                                    >Tambah ke <i class="fa fa-shopping-cart"></i
                                                ></a>
                                                </li>
                                                <li class="wishlist"></li>
                                            </ul>
                                            </div>
                                            <!-- <div class="label-sale">
                                                    -25%
                                                    </div> -->
                                        </div>
                                        <!--end item-inner -->
                                      </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <p>No products found in <?php echo e($category->name); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-4 col-xs-12 col-25 col-sidebar-left  col-col-left">
                  <?php echo $__env->make('site.core.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.core.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\petindo\resources\views/site/pages/category.blade.php ENDPATH**/ ?>