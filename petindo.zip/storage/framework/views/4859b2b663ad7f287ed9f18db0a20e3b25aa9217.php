<?php $__env->startSection('title', 'Search'); ?>

<?php $__env->startSection('content'); ?>
    <section class="main-home main-home-v2 main-blog">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="breadcrumb-grid breadcrumb-about">
                       <ul class="breadcrumb">
                          <li><a href="/">Home</a></li>
                          <li class="active"><a href="#">search</a></li>
                       </ul>
                    </div>
                 </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-10 col-md-9- col-sm-8 col-xs-12 col-75 col-col-right">
                    <div
                        class="main-home-page-right-content main-home-page-right-content-grid"
                    >
                        <div class="right-content-detail">
                            <?php $__empty_1 = true; $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 products-mb">
                                    <!-- item-inner -->
                                    <div class="item-inner">
                                        <?php if($product->images->count() > 0): ?>
                                            <div class="box-images">
                                            <a class="product-image" href="<?php echo e(route('product.show', $product->slug)); ?>" title=""
                                                ><img
                                                src="<?php echo e(asset('storage/'.$product->images->first()->full)); ?>"
                                                alt=""
                                            /></a>
                                            </div>
                                        <?php else: ?>
                                            <div class="box-images">
                                            <a class="product-image" href="<?php echo e(route('product.show', $product->slug)); ?>" title=""
                                                ><img
                                                src="https://via.placeholder.com/176"
                                                alt=""
                                            /></a>
                                            </div>
                                        <?php endif; ?>
                                        <div class="product-shop">
                                        <h2 class="product-name">
                                            <a href="<?php echo e(route('product.show', $product->slug)); ?>" title=""
                                            ><?php echo e($product->name); ?></a
                                            >
                                        </h2>
                                        <?php if($product->sub_name != ''): ?>
                                            
                                            <div class="sub-name"><?php echo e($product->sub_name); ?></div>
                                        <?php endif; ?>
                                        <div class="price-box">
                                            <p class="special-price">
                                                <span class="price-label">Special Price</span>
                                                <span class="price"><?php echo e(config('settings.currency_symbol').$product->price); ?></span>
                                            </p>
                                            <?php if($product->sale_price !=0): ?>
                                                <p class="old-price">
                                                <span class="price-label">Special Price</span>
                                                <span class="price"><?php echo e(config('settings.currency_symbol').$product->sale_price); ?></span>
                                                </p>
                                            <?php endif; ?>
                                        </div>
                                        <ul class="add-to-links">
                                            <li class="cart">
                                            <a href="cart.html" class="view-link" title=""
                                                >Tambah ke <i class="fa fa-shopping-cart"></i
                                            ></a>
                                            </li>
                                            <li class="wishlist"></li>
                                        </ul>
                                        </div>
                                        <!-- <div class="label-sale">
                                                -25%
                                                </div> -->
                                    </div>
                                    <!--end item-inner -->
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p>No Products found</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-4 col-xs-12 col-25 col-sidebar-left  col-col-left">
                    <div class="main-home-left-sidebar main-grid-left-sidebar">
                      <!-- categories-left -->
                      <div class="widget-v2 categories-left">
                        <aside class="categories-grid-inner">
                          <div class="sb-title ">
                            <h4>Kategori</h4>
                          </div>
                          <div class="categories-nav">
                            <div class="toggle-dropdown-menu">
                              <ul>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item->id !=1): ?>
                                        <li class="lever0">
                                            <a href="<?php echo e(route('category.show',$item->slug)); ?>"><span><?php echo e($item->name); ?></span></a>
                                        </li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                            </div>
                          </div>
                        </aside>
                      </div>
                      <!--end categories-left -->
                      <!--start shop by -->
                      <aside class="widget-v2 shopby">
                        <div class="sb-title ">
                          <h4>Shop by</h4>
                        </div>
                        <div class="shopby-inner">
                          <div class="shopby-widget">
                            <h3>Brand</h3>
                            <ul>
                              <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                  <a href="#"><?php echo e($brand->name); ?><span class="count">(<?php echo e($brand->products->count()); ?>)</span></a>
                                </li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                          </div>
                          <div class="shopby-widget">
                            <h3>Price</h3>
                            <div class="f-price">
                              <div id="slider-range" class="ui-slider ui-slider-horizontal ui-widget ui-widget-content ui-corner-all" aria-disabled="false"><div class="ui-slider-range ui-widget-header ui-corner-all" style="left: 0%; width: 60%;"></div><a class="ui-slider-handle ui-state-default ui-corner-all" href="#" style="left: 0%;"></a><a class="ui-slider-handle ui-state-default ui-corner-all" href="#" style="left: 60%;"></a></div>
                              <span><strong id="amount">$0 &gt; $300</strong></span>
                              <button class="btn btn-dashed textup" type="button">
                                Search
                              </button>
                            </div>
                          </div>
                        </div>
                      </aside>
                      <!--end -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.core.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\petindo\resources\views/site/pages/search.blade.php ENDPATH**/ ?>