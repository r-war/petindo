<?php $__env->startSection('title', 'Login'); ?>
    
<?php $__env->startSection('content'); ?>
    <section class="main-home">
        <div class="container">
            <div class="row">
                <!-- breadcrumb -->
                <div class="col-md-12">
                <div class="breadcrumb-grid breadcrumb-about">
                    <ul class="breadcrumb">
                        <li><a href="/">Home</a></li>
                        <li class="active"><a href="#">Login</a></li>
                    </ul>
                </div>
                </div>
                <!-- end breadcrumb -->
            </div>
            <div class="row container">
                <div class="col-md-6 mx-auto">
                    <form class="form-login"  method="post" action="<?php echo e(route('login')); ?>" accept-charset="utf-8">
                        <?php echo csrf_field(); ?>
                        <div class="form-login-text">
                        <p><span>Please log in below:</span></p>
                        <div class="form-group">
                            <label >email <span>*</span></label>
                            <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" id="email" value="<?php echo e(old('email')); ?>">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label >Password <span>*</span></label>
                            <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" id="password">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <p class="forgotpass">Don't Have Account? <a href="<?php echo e(route('register')); ?>" class="font-weight-bold" title="">Register </a></p>
                        </div>
                        
                        <input type="submit" class="button-form " >
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.core.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\petindo\resources\views/auth/login.blade.php ENDPATH**/ ?>