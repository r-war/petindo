    <!-- jQuery -->
    <script src="<?php echo e(asset('frontend/js/jquery-1.11.min.js')); ?>"></script>
    <!-- Bootstrap JavaScript -->
    <script src="<?php echo e(asset('frontend/js/bootstrap.min.js')); ?>"></script>
    <!-- Wocommerce JavaScript -->
    <script src="<?php echo e(asset('frontend/js/woocommerce.js')); ?>"></script>
    <!-- scroll-page JavaScript -->
    <script src="<?php echo e(asset('frontend/js/wow.min.js')); ?>"></script>
    <script>
        new WOW().init();
    </script>
    <!-- menu-mobile JavaScript -->
    <script src="<?php echo e(asset('frontend/js/menu-mobile.js')); ?>"></script>
    <!-- swiper JavaScript -->
    <script src="<?php echo e(asset('frontend/js/swiper.min.js')); ?>"></script>
    <!-- main JavaScript -->
    <script src="<?php echo e(asset('frontend/js/functions.js')); ?>"></script>

    <!-- revolution JavaScript -->
    <script src="<?php echo e(asset('frontend/js/jquery.themepunch.plugins.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/jquery.themepunch.revolution.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/scripts-revolution.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?><?php /**PATH C:\laragon\www\petindo\resources\views/site/core/scripts.blade.php ENDPATH**/ ?>