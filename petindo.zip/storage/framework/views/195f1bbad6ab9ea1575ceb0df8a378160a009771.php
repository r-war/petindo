<div class="tile">
    <form action="<?php echo e(route('admin.settings.update')); ?>" method="POST" role="form">
        <?php echo csrf_field(); ?>
        <h3 class="tile-title">Discount Settings</h3>
        <hr>
        <div class="tile-body">
            <div class="row">
                <div class="col-md-6">
                    <label class="control-label" for="site_name">Min. for shipping</label>
                    <input
                        class="form-control"
                        type="text"
                        placeholder="Enter site name"
                        id="site_name"
                        name="site_name"
                        value="<?php echo e(config('settings.shipping_min')); ?>"
                    />
                </div>
                <div class="col-md-6">
                    <label class="control-label" for="site_name">shipping value</label>
                    <input
                        class="form-control"
                        type="text"
                        placeholder="Enter site name"
                        id="site_name"
                        name="site_name"
                        value="<?php echo e(config('settings.shipping')); ?>"
                    />
                </div>
            </div>
            <div class="form-group">
            </div>
            <div class="form-group">
                <label class="control-label" for="site_title">Site Title</label>
                <input
                    class="form-control"
                    type="text"
                    placeholder="Enter site title"
                    id="site_title"
                    name="site_title"
                    value="<?php echo e(config('settings.site_title')); ?>"
                />
            </div>
        </div>
        <div class="tile-footer">
            <div class="row d-print-none mt-2">
                <div class="col-12 text-right">
                    <button class="btn btn-success" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Update Settings</button>
                </div>
            </div>
        </div>
    </form>
</div><?php /**PATH C:\laragon\www\petindo\resources\views/admin/settings/includes/discount.blade.php ENDPATH**/ ?>